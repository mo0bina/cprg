// mobina najafi
// 40223081


#include <stdio.h>
int main(){
    
    int n;
    printf("enter a positive integer named n : ");
    scanf("%d", &n);
    char input[n+1];
    printf("enter a string of length n :\n");
    
    for (int i=0; i<n+1 ; i++)
        scanf("%c" , &input[i]);
    
    
    
    int temp=1;
    /* inja temp ro tarif kardam bara inke ta jayi ke
    2 charactere moshabehe ham dare dobare halghe haro tekrar kone */
    while(temp==1) 
        for (int j=1 ; j<=n ;j++){
            if(input[j]== input[j+1]){
                for (j=j ; j <= n ; j++){
                  input[j]=input[j+2];
                  input[n+1]='\0';/*ino vaghti nemizashtam akhare reshteye jadid ghabliaro tekrar mikard 
                pas null gozashtam ke be manaye payane string bashe*/
                }
                /*inja ba peyda kardane 2 charactere moshabeh kari ke mikone ine ke tak take
                character haro 2 ta shift mide be aghab va oon 2 ta moshabeh hazf mishan*/
            
                printf("%s\n" , input);
            
                int counter=0 ;
                for (int k=1 ; k<=n ;k++){
                    if(input[k]!= input[k+1])
                        counter++ ;
                }
                /*in halghye for harbar check mikone ke aaya reshteye bedast oomade
                charactere moshabeh dare ya na age dige nadashte bashe , motaghayere temp
                ro avaz mikone ta dige while ejra nashe
                mishod in kar ro ba tabe ham anjam dad amma man har kar kardam natonestam 
                array ro be onvane input be function bedam baraye hamin intori zadam*/
                
                if(counter==n)
                    temp=0;
            
            }
        }

     return 0;
}
    
    



